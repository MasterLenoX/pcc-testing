<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LOGIN PAGE</title>
  <link rel="stylesheet" href="../pcc-testing/css/mystyle.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body class="bg-dark">
    <div class="PCC-mainbackground">

      <div class="login-banner">
        <div class="container">
          <h1 class="text-center text-light text-uppercase">welcome to <span class="text-primary">patient care <span class="text-info">corporation</span> </span> </h1>
          <br><br><br>
          <?php
          if (isset($_SESSION["userName"])) 
          {
          ?>        
            <h1 class="text-center text-uppercase">welcome - <?php echo $_SESSION['userName']; ?> </h1>
            <br>
            <a href="#" class="text-danger" id="logout">Logout</a>
          <?php
          } else {
          ?>
            <button type="button" class="btn btn-outline-primary text-light" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">
                <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514ZM11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/>
                <path d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z"/>
              </svg>
              SIGN ME IN
            </button>
          <?php
          }
          ?>
        </div>
      </div>


          <!-- Modal -->
          <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable">
              <div class="modal-content bg-dark border-3 border-primary">
                <div class="modal-header border-primary">
                  <!-- <h1 class="modal-title text-light fs-5" id="staticBackdropLabel">LOGIN FORM</h1> -->
                  <button type="button" class="btn btn-outline-danger text-light" data-bs-dismiss="modal">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
                      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                      <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                    </svg>
                  </button>
                </div>
                <div class="modal-body border-primary bg-transparent">
                  <div class="text-center">
                    <img src="../pcc-testing/images/logo/PCC_LOGO.png" width="100" height="100" class="rounded" >
                  </div>
                  <h1 class="text-light text-center">LOGIN</h1>
                  <hr class="featurette-divider">
                  <input type="text" name="userName" id="username" class="form-control" placeholder="Enter Username"/>
                  <br>
                  <input type="password" name="userPass" id="password" class="form-control" placeholder="Enter Password"/>
                  <br>
                  <button type="submit" name="login-btn" id="login_button" class="btn btn-outline-success text-light">LOGIN</button>

                </div>
                <div class="modal-footer border-primary">
                  <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
                  <!-- <button type="button" class="btn btn-primary">Understood</button> -->
                  <a href="#" class="text-info">forgot password?</a>
                </div>
              </div>
            </div>
          </div>





      <!-- footer -->
      <footer class="container">
        <!-- <p class="float-end"><a href="#">Back to top</a></p> -->
        <hr class="featurette-divider">
        <p class="text-info">Copyright &copy; 1973 - <span class="fw-bold text-warning"><?php echo date("Y");?></span> PATIENT CARE CORPORATION's BLOG &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </footer>

    </div>


    <!-- scripts -->
    <script>

$(document).ready(function(){  
      $('#login_button').click(function(){  
           var username = $('#username').val();  
           var password = $('#password').val();  
           if(username != '' && password != '')  
           {  
                $.ajax({  
                     url:"action.php",  
                     method:"POST",  
                     data: {userName:username, userPass:password},  
                     success:function(data)  
                     {  
                          //alert(data);  
                          if(data == 'No')  
                          {  
                               alert("Data Incorrect!");   
                          }  
                          else  
                          {  
                               $('#staticBackdrop').hide();  
                               location.reload();  
                          }  
                     }  
                });  
           }  
           else  
           {  
                alert("Both Fields are required");  
           }  
      });  
      $('#logout').click(function(){  
           var action = "logout";  
           $.ajax({  
                url:"action.php",  
                method:"POST",  
                data:{action:action},  
                success:function()  
                {  
                     location.reload();  
                }  
           });  
      });  
 });

      // $(document).ready(function() {
      //   $('#login_button').click(function(){
      //     var username = $('#username').val();
      //     var password = $('#password').val();
      //     if (username != '' && password != '') {
      //       $.ajax({
      //         url: "action.php",
      //         method:"POST",
      //         data:{username:userName,password:userPass},
      //         success: function(data){
      //           if(data == "no"){
      //             alert("Data is incorrect");
      //           } else {
      //             $('#staticBackdrop').hide();
      //             location.reload();
      //           }
      //         }
      //       });
      //     } 
      //     else{
      //       alert('Please enter Username and Password');
      //     }         
      //   });
      //   $('#logout').click(function(){
      //     var action = "logout";
      //     $.ajax({
      //       url: "action.php",
      //       method: "POST",
      //       data:{action:action},
      //       success: function(){
      //         location.reload();
      //       }
      //     })
      //   }); 
      // });
     
    </script>
   
    <!-- ajax scripts -->
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
          <!-- bootstrap scripts -->
          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>
</html>