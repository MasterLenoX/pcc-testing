/**
 *  Document   : editable_table_data.js
 *  Author     : redstar
 *  Description: script for editable table data
 *
 **/

 $('#mainTable').editableTableWidget();