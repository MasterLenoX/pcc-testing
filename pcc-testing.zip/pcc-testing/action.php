

<?php  
 session_start();  
 $connect = mysqli_connect("localhost", "root", "", "pcc-db");  
 if(isset($_POST["userName"]))  
 {  
      $query = "  
      SELECT * FROM pcc-test-user  
      WHERE userName = '".$_POST["userName"]."'  
      AND userPassword = '".$_POST["userPass"]."'  
      ";  
      $result = mysqli_query($connect, $query);  
      if(mysqli_num_rows($result) > 0)  
      {  
           $_SESSION['userName'] = $_POST['userName'];  
           echo 'Yes';  
      }  
      else  
      {  
           echo 'No';  
      }  
 }  
 if(isset($_POST["action"]))  
 {  
      unset($_SESSION["userName"]);  
 }  
 ?>  